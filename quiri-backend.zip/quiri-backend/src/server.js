const app = require("./app");

const PORT = 3000;

app.listen(PORT, () => {
  console.log(" Servidor Quiri rodando em http://localhost:3000");
});