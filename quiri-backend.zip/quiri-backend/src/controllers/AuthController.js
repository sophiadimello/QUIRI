class AuthController {

    cadastro(req, res) {

        const {
            nome,
            email,
            senha,
            confirmarSenha,
            tipo,
            crn,
            ufCRN
        } = req.body;

        // Verifica se todos os campos principais foram preenchidos
        if (!nome || !email || !senha || !confirmarSenha || !tipo) {
            return res.status(400).json({
                sucesso: false,
                mensagem: "Preencha todos os campos obrigatórios."
            });
        }

        // Verifica se as senhas são iguais
        if (senha !== confirmarSenha) {
            return res.status(400).json({
                sucesso: false,
                mensagem: "As senhas não coincidem."
            });
        }

        // Senha mínima
        if (senha.length < 8) {
            return res.status(400).json({
                sucesso: false,
                mensagem: "A senha deve possuir pelo menos 8 caracteres."
            });
        }

        // Tipo de usuário
        if (tipo !== "paciente" && tipo !== "nutricionista") {
            return res.status(400).json({
                sucesso: false,
                mensagem: "Tipo de usuário inválido."
            });
        }

        // Se for nutricionista
        if (tipo === "nutricionista") {

            if (!crn || !ufCRN) {

                return res.status(400).json({
                    sucesso: false,
                    mensagem: "Informe o CRN e o estado de registro."
                });

            }

        }

        return res.status(201).json({

            sucesso: true,

            mensagem: "Cadastro realizado com sucesso!",

            usuario: {
                nome,
                email,
                tipo,
                crn: crn || null,
                ufCRN: ufCRN || null
            }

        });

    }

}

module.exports = new AuthController();