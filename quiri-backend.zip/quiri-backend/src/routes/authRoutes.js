const express = require("express");

const router = express.Router();

router.post("/cadastro", (req, res) => {

    const { nome, email, senha, tipo } = req.body;

    res.status(201).json({
        mensagem: "Usuário cadastrado com sucesso!",
        usuario: {
            nome,
            email,
            tipo
        }
    });

});

module.exports = router;